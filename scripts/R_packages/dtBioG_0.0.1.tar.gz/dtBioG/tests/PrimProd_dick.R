calcPrimProd <- function(E = NA ,
                         PEpar = c(NA, NA, NA),
                         reflection = 0. ,
                         kd = 0.2 ,
                         mmole_mgC = 1/5*12 , #5 mole e / mole C * 12 mg C/ mole C
                         wc.layer = 1/1000 ,
                         wc.depth = 30 ,
                         wc.mids = seq(wc.layer/2, wc.depth-wc.layer/2, by = wc.layer)){
# light for each layer
wc.e <- (1-reflection)* E *exp(-kd*wc.mids)

# pp for each layer
wc.pp <- EP(PEpar, wc.e)[,2]

# integrated value
pp <- sum(wc.pp)*wc.layer*mmole_mgC #mgC m-2 h-1
pp
}

CleanFun <- function(FRRF, Fblanc_o=0, Fblanc_m=Fblanc_o){
  ff         <- na.omit(FRRF[, c("E", "X.Chl.", "Fo", "Fm", "Sigma", "RSigma", "QR", "ADC", "JVPII")])
  colnames(ff)[ncol(ff)] <- "JVPII_i"
  # correct for the blanc (fluorescence in the absence of Chl)
  ff$Foc     <- with(ff,  Fo - Fblanc_o) 
  ff$Fmc     <- with(ff,  Fm - Fblanc_m)
  
  ff$Fqc     <- with(ff,  Fmc - Foc    )
  #Kr/ELED = 11800e-6
  ff$a_LHII  <- with(ff,  Foc * Fmc / Fqc * (11800 / 10^6))    # absorption coefficient of Light Harvesting of PSII, /m
  ff$FqFm    <- with(ff,  Fqc/ Fmc  )                          # photosynthetic efficiency
  ff$JVPII   <- with(ff,  Fqc/ Fmc* a_LHII[1] * E * 3600/1000) # volumetric e-flux, [mmol m-3 h-1]
  return(ff)
}  

FitIt <- function(frrf, plotit=FALSE){

  FRRF <- CleanFun(frrf, Fblanc_o=0.3)

    # use the Eilers-Peeters model to fit the data
  FitEP <- PEfit("EP", PAR = FRRF$E , response = FRRF$JVPII)
  
  ATT <- attributes(frrf)$station
  main <- with(ATT, paste("Cast", Cast, " Tran", transect.nr ))
  Leg  <- with(ATT, c(paste(longitude, "E", latitude, "N"),Date.x))
  if (plotit){
    with(FRRF, plot(E, JVPII, main=main))
    legend("bottomright", Leg)
    lines(EP(FitEP$par, PAR=seq(0, max(FRRF$E), length.out=100)))
  }
  data.frame(ATT,alpha=FitEP$alpha, eopt=FitEP$eopt, ps=FitEP$ps, nrow=nrow(FRRF), maxE=max(FRRF$E), Chl = mean(FRRF$X.Chl.), 
    rsq = summary(FitEP)$sigma)
} 
