## =============================================================================
## Single Fits of FRRF data and the PE models
## =============================================================================


  #Define PE Models
  #Model.E refers to PE model normalized to irradiance, useful for fluorescence measures
  Webb   <- function(p,PAR) return(data.frame(x = PAR, y = p[1]*p[2]*(1-exp(-1*PAR/p[2]))))  
  Webb.E <- function(p,PAR) return(data.frame(x = PAR, y = p[1]*p[2]*(1-exp(-1*PAR/p[2]))/PAR))
  JP     <- function(p,PAR) return(data.frame(x = PAR, y = p[1]*p[2]*tanh(PAR/p[2])))  
  JP.E   <- function(p,PAR) return(data.frame(x = PAR, y = p[1]*p[2]*tanh(PAR/p[2])/PAR))
  PG     <- function(p,PAR) return(data.frame(x = PAR, y = p[3]*(1-exp(-1*p[1]*PAR/p[3]))*exp(-1*p[2]*PAR/p[3])))
  PG.E   <- function(p,PAR) return(data.frame(x = PAR, y = p[3]*(1-exp(-1*p[1]*PAR/p[3]))*exp(-1*p[2]*PAR/p[3])/PAR))
  EP     <- function(p,PAR) return(data.frame(x = PAR, y = PAR/((1/(p[1]*p[2]^2))*PAR^2+(1/p[3]-2/(p[1]*p[2]))*PAR+(1/p[1]))))
  EP.E   <- function(p,PAR) return(data.frame(x = PAR, y = 1/((1/(p[1]*p[2]^2))*PAR^2+(1/p[3]-2/(p[1]*p[2]))*PAR+(1/p[1]))))
  
## -----------------------------------------------------------
## Generate predictions based on an FRRF fit.
## -----------------------------------------------------------

predict.FRRF <- function(object, PAR, modargs = NULL, ...) {
  x <- PAR
  p <- object$par
  model <- object$model
  if (is.function(model) & is.null(modargs))
    if (!object$normalized) 
      return(model(p, x)$y)
    else
      return(model(p, x)$y/x)

  else if (is.function(model))
    if (!object$normalized) 
      return(do.call("model", c(alist(p, x), modargs))$y)
    else
      return(do.call("model", c(alist(p, x), modargs))$y/x)
      
  else if (model=="Webb"){# Webb et al. (1974) 
    
    if (!object$normalized) 
      return(Webb(p, x)$y)
    else                         # Model Normalized to E
      return(Webb.E(p, x)$y)
  
  } else if (model=="JP"){  # Jassby - Platt
  
    if (!object$normalized) 
     return(JP(p, x)$y)
    else 
      return(JP.E(p, x)$y)

  } else if(model=="PG"){
    
    if (!object$normalized) 
      return(PG(p, x)$y)
    else 
      return(PG.E(p, x)$y)
      
  } else if(model=="EP"){
    
    if (! object$normalized) 
      return(EP(p, x)$y)
    else 
      return(EP.E(p, x)$y)
  } else
    stop ("model '", model, "' not found")

}

## -----------------------------------------------------------
## Plot fitted model(s) versus the data 
## -----------------------------------------------------------

plotfit <- function(object, modargs = NULL, ...) {
  cl <- class(object)[1]
  if (!cl %in% c("FRRF", "multFRRF"))
   stop ("'object' not of correct class, should be created with PEfit or PEmult")

   dots <- list(...)
   if (is.null(dots$xlab)) 
     dots$xlab <- "PAR"
   
   ylab <- dots$ylab
   if (is.null(dots$ylab))
     dots$ylab <- "response"
       
   Plotit <- function(x) {
    do.call ("plot", c(alist(x = x$PAR, y = x$response), dots))
    PAR <- seq(min(x$PAR), max(x$PAR), length.out = 100) 
    pp <- predict (x, PAR = PAR, modargs = modargs)
    lines(PAR, pp)
   }
  if (cl == "FRRF") {
    Plotit(object)
  } else {
    nv <- length(object$ssr)
    nc <- min(ceiling(sqrt(nv)), 3)
    nr <- min(ceiling(nv/nc), 3)
    mfrow <- c(nr, nc)
    mf <- par(mfrow = mfrow)
    Ask <- prod(par("mfrow")) < nv && dev.interactive()
    ask <- par(ask = Ask)
    A <- attributes(object)$modFit
    obnames <- names(object$ids)
    for (i in 1:nv) {
      dots$main <- obnames[i]
      Plotit(A[[i]])
    }
    par(ask = ask) 
  }
}

## -----------------------------------------------------------
## Estimate r squared (uncorrected) of a fit
## -----------------------------------------------------------

r.squared <- function (object) {      # mss/(mss + rss)
  
  rsq.single <- function(x) {
    pred <- predict(x, PAR = x$PAR)
    mss <- sum((pred - mean(pred))^2)
    rss <- sum(x$residuals^2)
    mss/(mss + rss)
  }
  
  if (class(object)[1] == "FRRF")
    return(rsq.single(object))
  else {
    vec <- vector()
    for (i in 1:nrow(object$par))
      vec[i] <- rsq.single(attributes(object)$modFit[[i]])
    return(vec)
  }  
}

## -----------------------------------------------------------
## Find best-fit parameters
## -----------------------------------------------------------

PEfit <- function(model, PAR, response, normalized = FALSE, pini = NULL, 
  modargs = NULL, ...){
  
  x <- PAR
  y <- response
  
  if (normalized)  
    x[x==0] <- 1e-5       #Assign PAR = 0 to very small number
  
  fit <- list()
  
  #Initial Parameter Estimates  - in case pini = NULL
  if (is.null(pini)) {
    alpha <- 1 #max(y)
    ek    <- 500 # mean(range(x))
    beta  <- 1
    eopt  <- 2*ek
    ps    <- alpha*ek
  }
  if (is.function(model)) {
    if (!normalized) 
      model.1 <- function(p) (y - do.call("model", c(alist(p, x), modargs))$y)
    else
      model.1 <- function(p) (y - do.call("model", c(alist(p, x), modargs))$y/x)
    
    if (is.null(pini))
      stop("'pini' should be specified if the 'model' is a function")
    FIT <- try(modFit(f = model.1, p = pini,
                      ...), silent = TRUE)
    if (class(FIT) == "try-error")
      fit <- list(ms = NA, ssr = NA, 
                  residuals = rep(NA, length(x)), par = NA)
    else  {
      fit[1:length(pini)] <- FIT$par
      names(fit)[1:length(pini)] <- names(pini)
      fit <- c(fit, FIT)
    }  
  } else if (model == "Webb"){#Call Webb et al. (1974) Model Normalized to E
    
    if (!normalized) 
      model.1 <- function(p) (y - Webb(p, x)$y)
    else 
      model.1 <- function(p) (y - Webb.E(p, x)$y)

    if (is.null(pini)) {
      pini <- c(alpha = alpha, ek = ek)
    }  
    FIT <- try(modFit(f = model.1, p = pini,
                      lower = rep(0, 2), upper = c(Inf, 1500), 
                      ...), silent = TRUE)
    if (class(FIT) == "try-error")
      fit <- list(alpha = NA, ek = NA, ms = NA, ssr = NA, 
                  residuals = rep(NA, length(x)), par = NA)
    else
      fit <- c(fit, alpha = FIT$par[1], ek = FIT$par[2],FIT)
  }
  
  else if (model == "JP"){
  
    if (!normalized) 
      model.1 <- function(p) (y - JP(p, x)$y)
    else 
      model.1 <- function(p) (y - JP.E(p, x)$y)
    
    if (is.null(pini))
      pini <- c(alpha = alpha, ek = ek)
    FIT <- try(modFit(f = model.1, p = pini, 
                      lower = rep(0, 2),upper = c(Inf, 1500), 
                      ...), silent = TRUE)
    
    if (class(FIT) == "try-error")
      fit <- list(alpha = NA, ek = NA, ms = NA, 
                  ssr = NA, residuals = rep(NA, length(x)), par = NA)
    else
      fit <- c(fit, alpha = FIT$par[1], ek = FIT$par[2], FIT)
  }
  
  else if (model == "PG"){
    
    if (!normalized) 
      model.1 <- function(p) (y - PG(p, x)$y)
    else 
      model.1 <- function(p) (y - PG.E(p, x)$y)
    if (is.null(pini))
      pini <- c(alpha = alpha, beta = beta, ps = ps)
    FIT <- try(modFit(f = model.1, p = pini, 
                      lower = rep(0, 3), upper = c(Inf, 10, 1000),
                      ...), silent = TRUE)
    if (class(FIT) == "try-error")
      fit <- list(alpha = NA, beta = NA, ps = NA, 
                  ms = NA, ssr = NA, residuals = rep(NA, length(x)), par = NA)
    else
      fit <- c(fit, alpha = FIT$par[1], beta = FIT$par[2], ps = FIT$par[3], FIT)
  }
  
  else if (model == "EP"){
    
    if (!normalized) 
      model.1 <- function(p) (y - EP(p, x)$y)
    else 
      model.1 <- function(p) (y - EP.E(p, x)$y)
    
    if (is.null(pini))
      pini <- c(alpha = alpha, eopt = eopt, ps = ps)
    FIT <- try(modFit(f = model.1, p = pini, 
                      lower = rep(0, 3), upper = c(Inf, 1500, 1000), 
                      ...), silent = TRUE)
    if (class(FIT)=="try-error")
      fit <- list(alpha = NA, eopt = NA, ps = NA, 
                  ms = NA, ssr = NA, residuals = rep(NA, length(x)), par = NA)
    else
      fit <- c(fit, alpha = FIT$par[[1]], eopt = FIT$par[[2]], ps = FIT$par[[3]], FIT)    
  } else
    stop ("model '", model, "' not found")

  fit$PAR <- PAR
  fit$response <- response
  fit$model <- model
  fit$normalized <- normalized

  class(fit) <- c("FRRF", "modFit")
  return(fit)

}

  
