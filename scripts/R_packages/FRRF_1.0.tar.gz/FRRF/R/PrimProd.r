# example data
testdata <- function() {
depth <- seq(0, 2.6, by = 0.1)
surf  <- c(3075000,3065500,3056000,3046500,3037000,3027000,3017000,
  3007500,2998000,2988500,2979000,2967500,2956000,2944500,2933000,
  2922000,2911000,2899500,2888000,2876500,2865000,2853000,2841000,
  2828500,2816000,2804000,2792000)
cbind(depth, surf)
}
#morphology <- testdata()
primprod <- function(Fit,           # a fit, obtained with PEfit or with PEmult
                     morphology,    # two columns: depth, surface
                     PAR,           # two columns: time, radiation
                     kd) {          # extinction coefficient, one value or as many as in PAR
   nr <- nrow(morphology)
   md  <- 0.5* (morphology[-1,1] + morphology[-nr,1])  # mean depth
   vol <- 0.5* (morphology[-1,2] + morphology[-nr,2]) * diff(morphology[,1])  # volume
   sumvol <- sum(vol)

   VertPP <- function (par, Kd, FIT) {
     Iz <- par*exp(-Kd * md)
     sum(predict(FIT, Iz) * vol/sumvol) * diff(range(morphology[,1]))
   }

   if ("FRRF" %in% class(Fit))
     FindFit <- function(t) Fit
   else {
     timeFits <- attributes(Fit)$environment
     FindFit <- function(time) {
       ii <- which (timeFits$ini_time < time & timeFits$end_time >= time)
       if (is.null(ii))
         ii <- ifelse (timeFits$ini_time >= time, 1, length(timeFits$ini_time))
       FIT <- Fit
       class(FIT) <- c("FRRF", "modFit")
       FIT$par <- Fit$par[ii, ]
       FIT
     }
   }
   
   nrp <- nrow(PAR)
   kd <- rep(kd, length.out = nrp)
   TP <- sapply(1:nrp, function (i) VertPP(PAR[i,2], Kd[i], FindFit(PAR[i,1])))
   cbind(PAR, Kd = Kd, TP)
}

  