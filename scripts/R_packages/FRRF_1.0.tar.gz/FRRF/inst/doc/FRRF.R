### R code from vignette source 'FRRF.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
library(FRRF)
options(prompt = "> ")
options(width = 75)


###################################################
### code chunk number 2: FRRF.Rnw:123-124
###################################################
head(Webb)


###################################################
### code chunk number 3: FRRF.Rnw:129-130
###################################################
PAR <- 0:150


###################################################
### code chunk number 4: models
###################################################
par(mfrow = c(2, 2))
plot(Webb(p = c(alpha = 0.5, ek = 180), PAR = PAR), 
  main = "Webb", type = "l")
plot(JP  (p = c(alpha = 0.5, ek = 180), PAR = PAR), 
  main = "JP", type = "l")
plot(PG  (p = c(alpha = 0.5, beta = 1, ps = 180), PAR = PAR), 
  main = "PG", type = "l")
plot(EP  (p = c(alpha = 0.5, eopt = 180, ps = 50), PAR = PAR), 
  main = "EP", type = "l")


###################################################
### code chunk number 5: models
###################################################
par(mfrow = c(2, 2))
plot(Webb(p = c(alpha = 0.5, ek = 180), PAR = PAR), 
  main = "Webb", type = "l")
plot(JP  (p = c(alpha = 0.5, ek = 180), PAR = PAR), 
  main = "JP", type = "l")
plot(PG  (p = c(alpha = 0.5, beta = 1, ps = 180), PAR = PAR), 
  main = "PG", type = "l")
plot(EP  (p = c(alpha = 0.5, eopt = 180, ps = 50), PAR = PAR), 
  main = "EP", type = "l")


###################################################
### code chunk number 6: FRRF.Rnw:159-160
###################################################
args(PEfit)


###################################################
### code chunk number 7: FRRF.Rnw:164-166
###################################################
PAR <- seq(0, 100, length.out = 11)
response <- c(0, 1.6, 1.85, 1.95, 1.99, 2.0, 1.98, 1.95, 1.92, 1.88, 1.82)


###################################################
### code chunk number 8: FRRF.Rnw:169-173
###################################################
FitWebb <- PEfit("Webb", PAR = PAR, response = response)
FitPG   <- PEfit("PG",   PAR = PAR, response = response)
FitJP   <- PEfit("JP",   PAR = PAR, response = response)
FitEP   <- PEfit("EP",   PAR = PAR, response = response)


###################################################
### code chunk number 9: FRRF.Rnw:179-181
###################################################
summary(FitWebb)
summary(FitPG)


###################################################
### code chunk number 10: FitWebb
###################################################
plot(FitWebb)


###################################################
### code chunk number 11: FitWebb
###################################################
plot(FitWebb)


###################################################
### code chunk number 12: FRRF.Rnw:201-202
###################################################
c(deviance(FitWebb), deviance(FitPG), deviance(FitJP), deviance(FitEP))


###################################################
### code chunk number 13: predict
###################################################
par(mfrow = c(1, 1))
plot(PAR, response, ylim = c(0, 2))

# PAR for prediction
PARpred <- seq(0, 120, by = 1)

lines(predict(FitWebb, PARpred), lwd = 2)
lines(predict(FitPG, PARpred), col = "red", lwd = 2)
lines(predict(FitJP, PARpred), col = "blue", lwd = 2)
lines(predict(FitEP, PARpred), col = "green", lwd = 2)
legend("bottomright", c("Webb", "PG", "JP", "EP"), 
   col = c("black", "red", "blue", "green"), lty = 1, lwd = 2)

# use plotfit to look at single fits
par(mfrow = c(2,2))
plotfit(FitWebb, main = "Webb")
plotfit(FitPG, main = "Platt-Galegos")
plotfit(FitJP, main = "Jassby-Platt")
plotfit(FitEP, main = "Eilers-Peeters")


###################################################
### code chunk number 14: predict
###################################################
par(mfrow = c(1, 1))
plot(PAR, response, ylim = c(0, 2))

# PAR for prediction
PARpred <- seq(0, 120, by = 1)

lines(predict(FitWebb, PARpred), lwd = 2)
lines(predict(FitPG, PARpred), col = "red", lwd = 2)
lines(predict(FitJP, PARpred), col = "blue", lwd = 2)
lines(predict(FitEP, PARpred), col = "green", lwd = 2)
legend("bottomright", c("Webb", "PG", "JP", "EP"), 
   col = c("black", "red", "blue", "green"), lty = 1, lwd = 2)

# use plotfit to look at single fits
par(mfrow = c(2,2))
plotfit(FitWebb, main = "Webb")
plotfit(FitPG, main = "Platt-Galegos")
plotfit(FitJP, main = "Jassby-Platt")
plotfit(FitEP, main = "Eilers-Peeters")


###################################################
### code chunk number 15: FRRF.Rnw:249-253
###################################################
Monod <- function(p, PAR) {
  y <- p[1]*PAR / (PAR + p[2])
  list(x = PAR, y = y)
}


###################################################
### code chunk number 16: FRRF.Rnw:256-258
###################################################
PAR <- seq(0, 100, length.out = 11)
response <- c(0, 1.6, 1.85, 1.95, 1.99, 2.0, 1.98, 1.95, 1.92, 1.88, 1.82)


###################################################
### code chunk number 17: FRRF.Rnw:261-262
###################################################
FitMonod <- PEfit(Monod, PAR = PAR, response = response, pini = c(Rm = 2, ks = 25))


###################################################
### code chunk number 18: FRRF.Rnw:265-267
###################################################
summary(FitMonod)
coef(FitMonod)


###################################################
### code chunk number 19: FitMonod
###################################################
plotfit(FitMonod)


###################################################
### code chunk number 20: FitMonod
###################################################
plotfit(FitMonod)


###################################################
### code chunk number 21: FRRF.Rnw:294-299
###################################################
MonodT <- function(p, PAR, T) {
  
  y <- p[1]*PAR / (PAR + p[2]) * p[3]**((T-10)/10)
  list(x = PAR, y = y)
}


###################################################
### code chunk number 22: FRRF.Rnw:303-306
###################################################
PAR <- seq(0, 100, length.out = 11)
T   <- seq(15, 10, length.out = 11) 
response <- c(0, 1.6, 1.85, 1.95, 1.99, 2.0, 1.98, 1.95, 1.92, 1.88, 1.82)


###################################################
### code chunk number 23: FRRF.Rnw:310-312
###################################################
FitMonodT <- PEfit(MonodT, PAR = PAR, response = response, 
  pini = c(Rm = 2, ks = 25, Q10 = 2), modargs = list(T = T))


###################################################
### code chunk number 24: FRRF.Rnw:315-317
###################################################
summary(FitMonodT)
coef(FitMonodT)


###################################################
### code chunk number 25: FitMonodT
###################################################
par(mfrow = c(1, 1))
plotfit(FitMonodT, modargs = list(T = seq(15, 10, length.out = 100)), 
  main = "Monod*f(Temp)")


###################################################
### code chunk number 26: FitMonodT
###################################################
par(mfrow = c(1, 1))
plotfit(FitMonodT, modargs = list(T = seq(15, 10, length.out = 100)), 
  main = "Monod*f(Temp)")


###################################################
### code chunk number 27: FRRF.Rnw:345-346
###################################################
head(FRRFdata)


###################################################
### code chunk number 28: FRRF.Rnw:352-353
###################################################
 set  <- subset(FRRFdata, subset = (RLCset <= 5 & !is.na(FvFm)))


###################################################
### code chunk number 29: FRRF.Rnw:359-361
###################################################
 PEdata <- GetPEdata(set, which = "FvFm")
 tail(PEdata)


###################################################
### code chunk number 30: FRRF.Rnw:365-366
###################################################
 mFitEP <- PEmult("EP", PEdata$id, PEdata$PAR, PEdata$FvFm, normalized = TRUE)


###################################################
### code chunk number 31: FRRF.Rnw:370-371
###################################################
 summary(mFitEP)  # look at summary


###################################################
### code chunk number 32: FRRF.Rnw:374-375
###################################################
 coef(mFitEP)     # extract parameters


###################################################
### code chunk number 33: mFitEP
###################################################
par(mfrow = c(1, 1))
plotfit(mFitEP)


###################################################
### code chunk number 34: mFitEP
###################################################
par(mfrow = c(1, 1))
plotfit(mFitEP)


###################################################
### code chunk number 35: FRRF.Rnw:396-399
###################################################
 Par <- 1:1500 
 predEP <- predict (mFitEP, PAR = Par)
 head(predEP)


###################################################
### code chunk number 36: predictM
###################################################
 par (mfrow = c(1, 1))   
 matplot(Par, predEP, type = "l", lwd = 2, col = 1:10, lty = 1)
 legend("topright", legend = 1:10, lwd = 2, col = 1:10, lty = 1)
 points(PEdata[,-1], col = (1:10)[PEdata[,1]], pch = ".", cex = 4)


###################################################
### code chunk number 37: predictM
###################################################
 par (mfrow = c(1, 1))   
 matplot(Par, predEP, type = "l", lwd = 2, col = 1:10, lty = 1)
 legend("topright", legend = 1:10, lwd = 2, col = 1:10, lty = 1)
 points(PEdata[,-1], col = (1:10)[PEdata[,1]], pch = ".", cex = 4)


###################################################
### code chunk number 38: FRRF.Rnw:421-429
###################################################
 Monod <- function(p, PAR) {
  y <- p[1]*PAR / (PAR + p[2])
  list(x = PAR, y = y)
 }

 mFitMonod <- PEmult(Monod, PEdata$id, PEdata$PAR, PEdata$FvFm, normalized = TRUE, 
  pini = c(pm = 1, ks = 1))
 summary(mFitMonod)


