# ==============================================================================
# ==============================================================================
# From wide to long and vice versa
# ==============================================================================
# ==============================================================================

# rough estimate of the format, if not recorded in its attributes
getformat <- function(atts){
  
  if (! is.null(atts$format)) 
    format <- atts$format
  
  else if ("variable" %in% atts$names | 
           "value"    %in% atts$names) 
    format <- "long" 
  
  else 
    format <- "wide"  # can also be long!
  
  return(format)
}

# ==============================================================================

dtreshape <- function(x,                # data to reshape
                      swap="station"){  # the name of the column to expand or create
  
  atts   <- attributes(x)
  format <- getformat(atts)
  
  atts <- atts[!names(atts) %in% c( "names", "row.names")]
  if (format == "wide") {
    if (swap %in% names(x))
      stop("cannot create a column named ", swap, " as this already exists")
    xx <- dttolong(x, longname = swap)
    atts$processing <- c(atts$processing , 
             paste("reshaped to 'long' at ", Sys.time()))
    atts$format <- "long"
  
  } else {
    
    if (!swap %in% names(x))
      stop("cannot go to wide format based on ", swap, " as column does not exist")
    xx <- dttowide(x, column = swap)
    atts$processing <- c(atts$processing , 
             paste("reshaped to 'wide' at", Sys.time()))
    atts$format <- "wide"
  }
  attributes(xx) <- c(attributes(xx)[c("names", "row.names")],
                      atts)
  xx
}

# ==============================================================================

dttowide <- function(x, column="station"){
  
  cn <- colnames(x)
  
  # it is assumed that datetime marks the end of the id section
  nt    <- which(cn == "datetime")
  idvar <- cn   [1:nt]
  idvar <- idvar[-which(cn == column)]
  
  xx <- reshape(x, 
                direction="wide", 
                idvar   = idvar,   
                timevar = column, sep=".")
  
  cn  <- colnames(xx)
  cnx <- cn[ncol(xx)]
  zz <- gregexpr(".", cnx, fixed=TRUE)[[1]]
  hd <- substr(cnx, 1, zz)
  
  cn <- gsub(hd, "", cn)
  colnames(xx) <- cn  
  xx
}

# ==============================================================================

dttolong <- function (x, longname="variable"){
  
  cn <- colnames(x)
  
  # it is assumed that datetime marks the end of the id section
  nt    <- which(cn == "datetime")
  nc <- (nt+1):ncol(x)
  xx <- reshape(x, direction="long", timevar=longname, 
                varying = list(nc) , idvar="value")
  cnxx <- cn[nc]
  lookup <- data.frame(v=1:length(cnxx), name=cnxx)
  nn <- lookup$name[match(xx[,longname], lookup$v)]
  xx[,longname] <- nn
  xx <- xx[,-ncol(xx)]
  colnames(xx)[ncol(xx)] <- "value"
  xx
}

# ==============================================================================
# ==============================================================================
# pick time series for a specific location
# ==============================================================================
# ==============================================================================

# ==============================================================================
# Check if a point falls in a triangle
# ==============================================================================

ptintri <- function(P = c(1,  3), 
                    Triangle.x, Triangle.y){   
  # A =[ux  vx  wx  # Trianglex
  #     uy  vy  wy
  #      1   1   1]
  A <- rbind(Triangle.x, 
             Triangle.y, 
             rep(1, 3))
  B <- c(P, 1)
  all(solve(A, B) > 0)
}

# ==============================================================================
# calculates coefficients for triangular interpolation
# ==============================================================================

ptcoeff <- function(P = c(1,  3), 
                    Triangle.x, 
                    Triangle.y){   # matrix; 2 rows * 3 columns
  # A =[ux  vx  wx
  #     uy  vy  wy
  #      1   1   1]
  A <- rbind( Triangle.x, Triangle.y, rep(1, 3))
  B <- c(P, 1)
  solve(A, B)
}

# ==============================================================================
# Creates all unique triangles from a set of points
# ==============================================================================

CreateTriangles <- function(n=5){   
  Triangles <- expand.grid(1:n, 2:n, 3:n)
  
  # check for same points- in each set of 3
  TT        <- apply(Triangles, MARGIN=1, FUN=anyDuplicated)  
  Triangles <- Triangles[TT==0, ]                             
  
  # check for same rows
  Triangles <- t(apply(Triangles, 
                       MARGIN=1, 
                       FUN=function(x) x[order(x)]))
  TT        <- unique(apply(Triangles, 
                            MARGIN=1, 
                            FUN=function(x) paste(x, collapse="_")))
  Triangles <- matrix(ncol=3, 
                      data=as.integer(unlist(strsplit(TT, "_"))), 
                      byrow=TRUE)
  
  return(Triangles)
}

# ==============================================================================
# https://codeplea.com/triangular-interpolation
# Barycentric Coordinates
# as not enough evenly spread weather stations to cover the entire region.
# ==============================================================================

pick_xyt <- function(longitude=5.2, latitude=53.2, 
                     input=NULL,
                     output.t=unique(input$datetime),
                     what="waterheight",
                     shape=Wadshape,
                     plotit = FALSE, 
                     n      = NULL,
                     verbose = FALSE,
                     ...){
  # 1. check if longitude, latitude fall in the Waddensea. 
  #    Check if 'station' attribute is present in object
  if (what == "waterheight"){
    if (is.null(input)) input <- HeightHR
    pickdata(longitude=longitude, latitude=latitude, 
             output.t=output.t, input=input, 
             shape=shape, plotit=plotit, n=n, verbose=verbose, 
             what=what, ...)
    
  } else if (what == "temperature") {
    if (is.null(input)) input <- TempHR
    pickdata(longitude=longitude, latitude=latitude, 
             output.t=output.t, input=input, 
             shape=shape, plotit=plotit, n=n, verbose=verbose, 
             what=what, ...)
    
  } else if (what %in% colnames(RWSbiogeo2021)){
    if (is.null(input)) {
      select <- c("station", "longitude", "latitude",  "datetime", what) 
      input <- RWSbiogeo2021[, select]
      attributes(input)$format <- "long"
      input <- dtreshape(input, swap="station")
    }
    pickdata(longitude=longitude, latitude=latitude, 
             output.t=output.t, input=input, 
             shape=shape, plotit=plotit, n=n, verbose=verbose, 
             what=what, ...)
  } else {
    if (is.null(input)) stop (" 'input' should be provided for variable ", what)
    pickdata(longitude=longitude, latitude=latitude, 
             output.t=output.t, input=input, 
             shape=shape, plotit=plotit, n=n, verbose=verbose, 
             what=what, ...)
  }
}

# ==============================================================================
# Interpolation using barycentric coordinates
# ==============================================================================

pickdata <- function(longitude=5.2, latitude=53.2, 
                     depth= NA,  # depth versus NAP
                     from="2021-01-01", to="2021-02-01", by=3600,
                     output.t=seq(as.POSIXct(from),     # default = hourly
                                  as.POSIXct(to), 
                                  by=by),
                     what = "waterheight",
                     input  = HeightHR,
                     stats = attributes(input)$stations,
                     plotit = FALSE, 
                     n      = NULL,
                     shape  = Wadshape,
                     verbose = FALSE, ...){

  if (!attributes(input)$format == "wide"){
    
    stop ("can only do this in wide format")
    
  }

  output.t <-  output.t [order(output.t)]
  
  # Make a selection of the input based on times
  if (is.numeric(output.t)) # index to the datetime
    input <- input[output.t,]
  else {
    ii <- which(input$datetime >= min(output.t) &     
                  input$datetime <= max(output.t))
    if (! length(ii))
      stop ("cannot interpolate: no overlap in time between input and output.t")
    ir <- range(ii) + c(-1,1)   # one more before and after
    ir <- pmin(nrow(input), ir)
    ir <- pmax(ir, 1)
    input  <- input[ir[1]:ir[2], ]
    ist     <- which(colnames(input) %in% stats$station)
    notNAs  <- apply(input[,ist], MARGIN=2, FUN=function(x) sum(!is.na(x))) 
    iremove <- names(notNAs)[which(notNAs <= 2)]
    if (length(iremove)){
      if (verbose) warning("removing station ", iremove, " as this has too many NAs")
      input <- input[, -which(colnames(input) %in% iremove)]
      stats    <- stats[! stats$station %in% iremove, ]   # station information
    }
  }
  
  
  # distance between the point and all stations - order stations
  asp      <- 1/cos((mean(latitude)*pi)/180)        # y/x aspect ratio
  Dist2    <- (stats$longitude - longitude)^2+      # distance^2
              (stats$latitude  -  latitude)^2*asp^2
  Dsort    <- sort.int(Dist2, index.return=TRUE)$ix  
  
  # create surrounding triangles based on closest points
  if (is.null(n)) n <- 20
  ntri     <- min(n, nrow(stats))
  stats    <- stats[order(Dsort)[1:ntri],]

  # Creates all unique triangles from a set of points
  Triangles   <- CreateTriangles(ntri)
  Triangles.x <- matrix(ncol=3, 
                        data=stats$longitude[Triangles])
  Triangles.y <- matrix(ncol=3, 
                        data=stats$latitude [Triangles])

  # from triangles that embrace point: find one with smallest mean distance
  P    <- c(longitude, latitude)
  Keep <- meanD <-  NULL
  ic   <- 0
  
  for (i in 1:nrow(Triangles)){
     if (ptintri(P, 
                 Triangles.x[i,], Triangles.y[i,])) {  # point falls in triangle
       
       Keep  <- c(Keep, i)
       meanD <- c(meanD,                          # mean distance of point to edges
                  mean(sqrt((Triangles.x[i,]-longitude)^2 +
                           ((Triangles.y[i,]-latitude)*asp)^2)))
     }
  }
  
  # point is enclosed by triangle(s) 
  if (! is.null(Keep)){
    
      i          <- Keep[which.min(meanD)]
      statselect <- stats[Triangles[i, ],]

      # weighing coefficients
      wu <- ptcoeff(P, Triangles.x[i,], Triangles.y[i,])
      legtitle <- "surrounding triangle"
      
  } else {                    # point is NOT enclosed by triangle(s) 
     if (verbose) 
       warning("no surrounding points found - used the 3 closest points")
     
     statselect <- stats[1:3, ]  # 3 closest points
     
     # weighing coefficients : inverse distance 
     distance   <- sqrt((statselect$longitude-longitude)^2 +
                       ((statselect$latitude-latitude)*asp)^2)
     wu <- 1/distance
     wu <- wu/sum(wu)
     legtitle <- "3 closest points"
  }

  statnames  <- statselect$station
  
  if (plotit) {
      par(mfrow=c(2,1))
      xlim <- range(c(stats$longitude, longitude))
      ylim <- range(c(stats$latitude, latitude))
      with(stats, 
           plot(x=longitude, y=latitude, 
                xlim=xlim, ylim=ylim, col="darkgrey", 
                pch=18, asp=asp, main="selected stations"))
      plot(Wadshape[1], add=TRUE)
    
    if (! is.null(Keep)){
      # All triangles in which the point lies
      invisible(
        lapply(Keep, 
             FUN=function(i)polygon(Triangles.x[i,], 
                                  Triangles.y[i,], 
                                  lwd=0.5, border="grey")))
       polygon(Triangles.x[i,], Triangles.y[i,], 
            col=alpha.col("skyblue", alpha=0.3))
    }
    
    points(statselect$longitude, statselect$latitude, 
           pch=16, cex=1.5, col=2:4)
    
    points(longitude, latitude, cex=1.5, pch=16)
    
    legend("bottomright", ncol=2,
           legend =c(statnames,
                     format(wu, digits=2)), 
           title = legtitle, 
           pch=16, col=2:4, cex=0.75)
    
  }
  
    
    # select only input stations we need 
    input <- input[,c("datetime", statnames)]         # stations

    # interpolate time series to the requested output times
    res <- apply(input[,-1], MARGIN=2,
                 FUN = function(v) approx(x=input[ ,1], 
                         y=v, xout=output.t, 
                         rule=2)$y)     
   
    # take weighted average of input data: multiply all columns (margin=2)
    # with correct weighing factor (wu) and sum over the rows
    res <- data.frame(datetime=output.t, 
               rowSums(sweep(res, 
                             MARGIN = 2, 
                             STATS  = wu, 
                             FUN    = "*"), 
                       na.rm=TRUE))
    colnames(res)[2] <- what
    
    if (! is.na(depth))
      res[,2] <- pmax(res[,2], -depth)
    
    res <- res[order(res[,1]), ]
    if (plotit){
       matplot(input[,1], input[,-1], type="l", lty=1, lwd=1,
               col=2:4, xlab="time", 
               main=paste("timeseries of", what), ... )
       lines(res, lwd=2)
     }
     attributes(res)$input     <- input
     attributes(res)$weights   <- wu
     attributes(res)$selected  <- statselect
     
   
  res
}

# pick_xyt(plotit=TRUE)
# A <- pick_xyt(plotit=TRUE, input=TempHR, output.t=1:40)
# A <- pick_xyt(plotit=TRUE, input=TempHR, output.t=seq(from=as.POSIXct("2021-03-01"),to= as.POSIXct("2021-05-01"), by=60))
# A <- pick_xyt(plotit=TRUE, input=TempHR)
# A <- pick_xyt(plotit=TRUE, input=TempLR, output.t = seq("15-01-2021", "15-12-2021", by=3600*24))
#  A <- pick_xyt(plotit=TRUE, input=TempHR, output.t=seq(from=as.POSIXct("2021-03-01"),to= as.POSIXct("2021-03-31"), by=60), verbose=TRUE, ylab="m", latitude=53.15)

#  A <- pick_xyt(plotit=TRUE, what="NH4", input=RWSbiogeo2021, verbose=TRUE, ylab="m", latitude=53.15)
