
## ==========================================
## ==========================================
## make datasets globally available
## ==========================================
## ==========================================

if (getRversion() >= "2.15.1")  
  utils::globalVariables(c("Waddensea", "Marsdiep", "Grain", 
                           "HeightHR", "Height2021", 
                           "TempHR", "TempLR", "Temp2021",
                           "Weather2021", "Wadshape",
                           "KNMIstations", "RWSbiogeo2021"))

## ==========================================
## Subsetting without loosing the attributes
## ==========================================

`[.dtWad` <- function(x, i, j, ...) {
  attrs <- attributes(x)
  cls   <- class(x)
  out   <- x
  class(out)   <- "data.frame"
  out   <- out[i,j, ...]
  
  if (is.data.frame(out)){
    atout <- attributes(out)
    attributes(out) <- c(attributes(out), attrs[!names(attrs) %in% names(atout)])
    class(out) <- c("dtWad", class(out))
    # adapt stations and variables  
    nout <- names(out)
    if ("station" %in% nout & ! is.null(attributes(out)$stations)){
      stations <- unique(out$station)
      attstat <- attributes(out)$stations
      attstat <- subset(attstat, subset=attstat$station %in% stations)
      attributes(out)$stations <- attstat
    } else if (! is.null(attributes(out)$stations)) {
      attstat <- attributes(out)$stations
      ii <- which(!attstat$station  %in% colnames(out))
      if (length(ii)) attstat <- attstat[-ii, ]
      attributes(out)$stations <- attstat
      
    }
    if ("variable" %in% nout & ! is.null(attributes(out)$variables)){
      variables <- unique(out$variable)
      attvar <- attributes(out)$variables
      attvar <- subset(attvar, subset=attstat$variable %in% variables)
      attributes(out)$variables <- attvar
    }
    new <- "Selected" 
    if (! missing(i) & ! missing(j)) 
      new <- paste(new, length(i), "rows and", length(j), "columns") 
    else if (! missing(i)) new <- paste(new, length(i), "rows") 
    else if (! missing(j)) new <- paste(new, length(j), "columns")
  
    attributes(out)$processing <- c(attributes(out)$processing,
                                  paste(new, "at", Sys.time()))
  } 
  out
}

## ==========================================

subset.dtWad <- function(x, subset, ..., attr=NULL){
  attrs <- attributes(x)
  cls   <- class(x)
  out   <- x
  class(out)   <- "data.frame"

  e <- substitute(subset)
  r <- eval(e, out, parent.frame())
  if (!is.logical(r)) stop("'subset' must be logical")
  r <- r & !is.na(r)
  if (length(r) != nrow(out)) stop ("'subset' evaluation did not provide a selection?")
  if (sum(r) == 0) stop ("'subset' evaluation did not provide a selection?")
  
  out <- out[r,]    # take subset

  if (is.data.frame(out)){
    atout <- attributes(out)
    attributes(out) <- c(atout, attrs[!names(attrs) %in% names(atout)])

    attributes(out)$processing <- c(attributes(out)$processing,
                                   paste("Subsetted", sum(r), "from", nrow(x), "rows at", Sys.time())
                                  )
    if (length(attr))
      attributes(out) <- c(attributes(out), attr)

    # adapt stations and variables  
    nout <- names(out)
    if ("station" %in% nout & ! is.null(attributes(out)$stations)){
      stations <- unique(out$station)
      attstat <- attributes(out)$stations
      attstat <- attstat[attstat$station %in% stations,]
      attributes(out)$stations <- attstat
    }
    if ("variable" %in% nout & ! is.null(attributes(out)$variables)){
      variables <- unique(out$variable)
      attvar <- attributes(out)$variables
      attvar <- attvar[attvar$variable %in% variables,]
      attributes(out)$variables <- attvar
    }
    
    class(out) <- cls
  }
  out
}
