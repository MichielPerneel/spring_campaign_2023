# ==============================================================================
# ==============================================================================
# Interpolate time series defined in (xy) points to other (xy) points 
# ==============================================================================
# ==============================================================================

interpolate_xyt <-  function(input.xytv,  # longitude (x), latitude (y), time, value
                             output.xy, output.t, 
                             wide=TRUE){  # wide or long format
  
  attrs <- NULL
  if (inherits(input.xytv, "dtWad"))
    attrs <- attributes(input.xytv)
  
  # input.xytv: 4 columns: longitude (x), latitude (y), time, value
  if (ncol(input.xytv) != 4) 
    stop ("'input.xytv' should have 4 columns: longitude (x), latitude (y), time, value")

  # different xy values

  input.xy  <- unique(input.xytv[, 1:2])
  ni <- nrow(input.xy)
  
  if (is.vector(output.xy))
    output.xy <- matrix(nrow=1, data=output.xy)
  else 
    output.xy <- unique(output.xy[,1:2])
  coord.xy  <- output.xy
  no <- nrow(output.xy)
  
  ##### step 1: weighting points #####
  # distance between two points
  # euclidean_distance
  
  DD1 <- outer(output.xy [, 1], input.xy[, 1], FUN="-")
  DD2 <- outer(output.xy [, 2], input.xy[, 2], FUN="-")
  Distance <- sqrt(DD1^2+DD2^2)
  rm(list=c("DD1", "DD2"))
  
  # find three closest points 
  # which data sets to use for each output station, 
  imin <- min(3, ni)  # at most 3 columns selected
  i.close <- matrix(nrow=no, byrow=TRUE, 
                    data=unlist(apply(Distance, 
                                      MARGIN = 1, 
                                      FUN    = order, 
                                      simplify=FALSE)))[,1:imin]

  # weighing values ~ inverse distance
  w.close <- NULL
  for (i in 1:ncol(i.close))
     w.close <- cbind(w.close, 
                      Distance[cbind(1:nrow(i.close), i.close[,i])])
  ii <- which(w.close == 0)
  w.close <- 1/w.close
  
  # rescale so that sum=1
  w.close   <- w.close/rowSums(w.close, na.rm=TRUE)
  
  if (length(ii)) w.close[ii] <- 1
  w.close[is.nan(w.close)] <- 0
  
  # columns that are used in weighing
  i.unique <- unique(as.vector(i.close))
  
  ##### step2: interpolate to times for all inputs #####
  xytin <- matrix(nrow=length(output.t), ncol=max(i.unique))
  
  for (i in i.unique){
    # interpolate to required times
    ii <- which(input.xytv[,1] == input.xy[i,1] & 
                input.xytv[,2] == input.xy[i,2])
    V.out  <- approx(x=input.xytv[ii,3], y=input.xytv[ii,4], xout=output.t)$y
    xytin[,i] <- V.out
  }
  
  stnames <- paste("st", 1:no, sep="")
  Stations <- data.frame(stations=stnames,
                         x=coord.xy[,1], 
                         y=coord.xy[,2])
  row.names(Stations) <- NULL
  
  if (wide){
    result     <- matrix(nrow = length(output.t), 
                         ncol = 1+nrow(output.xy))
    result[,1] <- output.t

    for (i in 1:no){
      iu <- xytin[ ,i.close[i,]]  # data that need to be averaged
      wu <- w.close[i,]           # averaging weights
      result[,i+1] <- rowSums(sweep(iu, MARGIN=2, STATS=wu, FUN="*"))
    }
  
    colnames(result) <- c("time", stnames)
  } else {
    result     <- NULL
    for (i in 1:no){
      iu  <- xytin[ ,i.close[i,]]  # data that need to be averaged
      wu  <- w.close[i,]           # averaging weights
      res <- rowSums(sweep(iu, MARGIN=2, STATS=wu, FUN="*"))
      result <- rbind(result,  
                      cbind(Stations[i,], output.t, res, row.names=NULL))
    }
    
  }
  atout <- attributes(result)
  if (! is.null(attrs))
    attributes(result) <- c(atout, attrs[!names(attrs) %in% names(atout)])
  
  attr(result, "stations") <- Stations
  attr(result, "processing") <- c(
    atout$processing, paste("interpolated from 2D-time input, at:", Sys.time()))
  result
}

# ==============================================================================
# ==============================================================================
# Maps xy points to other xy points - uses least distance weighing 
# (3 closest pts) 
# ==============================================================================
# ==============================================================================

map_xy <-  function(input.xyv, # latitude (x), longitude (y), value
                    input.x, input.y, input.2D,
                    output.xy, 
                    output.x, output.y){
  # check input
  if (missing (input.xyv)){
    if (missing(input.x) | missing(input.y) | missing(input.2D) )
      stop("either input.xyv should be input or (input.x, input.y & input.2D)")
  }
    
  # check output
  if (missing (output.xy)){
    if (missing(output.x) | missing(output.y) )
      stop("either output.xy should be input or (output.x & output.y)")
  }
  
  # call correct function
  if (! missing(input.xyv) & 
      ! missing (output.xy))
    return(interpolate_xy_xy(input.xyv = input.xyv, # latitude (x), longitude (y), value
                             output.xy = output.xy) )
  else if (! missing(input.x) & ! missing(input.y) & ! missing(input.2D) & 
           ! missing(output.xy))
    return(interpolate_2D_xy (input.x=input.x, 
                           input.y=input.y, # latitude (x), longitude (y)
                           input.2D=input.2D,         #  depth
                           output.xy=output.xy))
  else if (!missing(input.xyv) & ! missing(output.x) & 
           !missing(output.y))
    return(interpolate_xy_2D(input.xyz=input.xyv, 
                  output.x=output.x, 
                  output.y=output.y))
  else if (! missing(input.x) & ! missing(input.y) & ! missing(input.2D) & 
           ! missing(output.x) & !missing(output.y))
    return(interpolate_2D_2D (input.x =input.x, 
                              input.y =input.y, 
                              input.2D=input.2D, 
                              output.x=output.x, 
                              output.y=output.y))
  
  else 
    stop ("one of the required arguments is missing")
      
}

# ==============================================================================

interpolate_xy_xy <-  function(input.xyv, # latitude (x), longitude (y), value
                            output.xy){
  
  if (ncol(input.xyv) != 3) 
    stop ("'input.xyv' should have 3 columns: latitude (x), longitude (y), value")

  ##### step 1: weighting points #####
  # distance between two points 

  input.xy  <- input.xyv[, 1:2]
  ni <- nrow(input.xy)
  if (ni == 0) stop("input.xyv is empty")
  
  output.xy <- unique(output.xy)
  coord.xy <- output.xy[,1:2]
  no <- nrow(output.xy)
  if (no == 0) stop("output.xy is empty")

  # euclidean_distance
  
  DD1 <- outer(output.xy [, 1], input.xy[, 1], FUN="-")
  DD2 <- outer(output.xy [, 2], input.xy[, 2], FUN="-")
  Distance <- sqrt(DD1^2+DD2^2)
  rm(list=c("DD1", "DD2"))
  
  
  # which data sets to use for each output station, 
  imin <- min(3, ni)  # at most 3 columns selected
  
  # find three closest points - this is slightly faster, but less clear
  #  ir   <- 1: no
  #  C1 <-apply(Distance, MARGIN=1, FUN=which.min)
  #  Distance[cbind(ir, C1)] <- NA
  
  #  C2 <- apply(Distance, MARGIN=1, FUN=which.min)
  #  if (! length(C2)) C2 <- NA else Distance[cbind(ir, C2)] <- NA
  
  #  C3 <- apply(Distance, MARGIN=1, FUN=which.min)
  #  if (! length(C3)) C3 <- NA 
  
  #    i.close   <- cbind(C1, C2, C3)
  #    w.close   <- 1/cbind(Distance[cbind(ir,C1)], 
  #                         Distance[cbind(ir,C2)], 
  #                         Distance[cbind(ir,C3)]) 

  i.close <- matrix(nrow=no, byrow=TRUE, 
                    data=unlist(apply(Distance, 
                                      MARGIN   = 1, 
                                      FUN      = order, 
                                      simplify = FALSE)))[,1:imin]
# weighing values ~ inverse distance
  w.close <- NULL
  for (i in 1:ncol(i.close))
    w.close <- cbind(w.close, 
                     Distance[cbind(1:nrow(i.close), i.close[,i])])
  
  ii <- which(w.close == 0)
  
  # weighing values ~ inverse distance
  w.close <- 1/w.close
  
  # rescale so that sum=1
  w.close   <- w.close/rowSums(w.close, na.rm=TRUE)
  if (length(ii)) w.close[ii] <- 1
  w.close[is.nan(w.close)] <- 0
  
  
  # columns that are used in weighing
  i.unique <- unique(as.vector(i.close))

  ##### step2: interpolate #####

  result <- sapply(1:no, FUN=function(i) sum(w.close[i,]*input.xyv[i.close[i,],3]))
  result <- data.frame(coord.xy, value=result)
  colnames(result)[3]<- colnames(input.xyv)[3]
  
  attr(result, "processing") <- paste("interpolated from 2D input, at:", 
                                      Sys.time())
  result
}

# ==============================================================================
# ==============================================================================
# interpolate 2D gridded points to xy points
# ==============================================================================
# ==============================================================================

interpolate_2D_xy <-  function(
                        input.x, input.y, # latitude (x), longitude (y)
                        input.2D,         #  depth
                        output.xy){

  dlon <- diff (input.x)  # diff(input.2D$longitude)
  dlat <- diff (input.y)  # diff(input.2D$latitude)
  
  equidistant <- diff(range(dlon)) == 0 &
                 diff(range(dlat)) == 0
  
  if (! equidistant){  # SLOW!
   input.2D.grid        <- expand.grid(input.x, input.y)
   names(input.2D.grid) <- c("longitude", "latitude")
   input.2D.grid$depth  <- as.vector(input.2D)
   input.2D.grid        <- na.omit(input.2D.grid)

   gg    <- na.omit(output.xy)
  
   Result <- map_xy(input.xyv = input.2D.grid, 
                    output.xy = gg[,1:2])
  } else {
    lonmin <- min(input.x)
    latmin <- min(input.y)
    ilon   <- function(x) 1+(x-lonmin)/dlon[1]
    ilat   <- function(x) 1+(x-latmin)/dlat[1]
    ix  <- sapply(output.xy[,1], FUN=ilon)
    iy  <- sapply(output.xy[,2], FUN=ilat)
    iix <- pmin(length(input.x) , as.integer(ix))  # index to pt on left
    iiy <- pmin(length(input.y) , as.integer(iy))  # index to pt below

    dx  <- (output.xy[,1]-input.x[iix]) /dlon[1]
    dy  <- (output.xy[,2]-input.y[iiy] ) /dlat[1]
    dxvalue <- input.2D[,-1] - input.2D[,-ncol(input.2D)]
    dxvalue <- cbind(0, dxvalue, 0)
    dyvalue <- input.2D[-1,] - input.2D[-nrow(input.2D),]
    dyvalue <- rbind(0, dyvalue, 0)
    
    newdepth <- input.2D[cbind(iix, iiy)]+
                0.5*(dxvalue[cbind(iix, iiy)]*dx[iix] +
                     dyvalue[cbind(iix, iiy)]*dy[iiy]) 
    row.names(output.xy) <- NULL
    Result <- data.frame(output.xy, depth=newdepth)
    names(Result)[ncol(Result)] <- "z"
  }
  Result 
}

# ==============================================================================
# ==============================================================================
# maps xy values on a 2D regular grid
# ==============================================================================
# ==============================================================================

interpolate_xy_2D <- function(input.xyz, 
                   output.x=NULL, output.y=NULL){
  
  if (is.null(output.x)) 
    output.x <- sort(unique(input.xyz[,1]))
  if (is.null(output.y)) 
    output.y <- sort(unique(input.xyz[,2]))
  
  xo  <- unique(output.x)
  xor <- range(xo)
  dxo <- diff(xor)/(length(xo)-1)
  
  yo <- unique(output.y)
  yor <- range(yo)
  dyo <- diff(yor)/(length(yo)-1)
  
  dxi <- min(diff(sort(unique(input.xyz[,1]))))
  dyi <- min(diff(sort(unique(input.xyz[,2]))))
  
  if (dxi > dxo | dyi > dyo) {
    Ux <- diff(range(diff(sort(unique(input.xyz[,1])))))
    Uy <- diff(range(diff(sort(unique(input.xyz[,2])))))
    if (Ux == 0 & Uy == 0) {  # uniform grid
       OO <- interpolate_xy_2D(input.xyz, output.x=NULL, output.y=NULL)
       return(interpolate_2D_2D(OO$x, OO$y, OO$z, output.x, output.y))  # RECURSIVE!!!??
    }
    else stop("cannot map: input resolution too low and nonuniform input grid")
  } else {
  # map input to output grid cells
  ix <- as.integer(1+(input.xyz[,1]-xor[1])/dxo)
  iy <- as.integer(1+(input.xyz[,2]-yor[1])/dyo)
  
  ix.lack <- which(!1:length(output.x) %in% unique(ix))
  iy.lack <- which(!1:length(output.y) %in% unique(iy))
  
  lx <- length(ix.lack)
  ly <- length(iy.lack)
  if (lx+ly) {
    if (!lx) ix.lack <- 1
    if (!ly) iy.lack <- 1
    ix.lack <- rep(ix.lack, length.out=lx+ly)
    iy.lack <- rep(iy.lack, length.out=lx+ly)
    ix <- c(ix, ix.lack)
    iy <- c(iy, iy.lack)
    toadd <- input.xyz[1:(lx+ly), ]
    toadd[,] <- 0
    input.xyz <- rbind(input.xyz, toadd)
    }
  
  # sum all variables within a grid cell, and count the number of elements
  zsum <- tapply(input.xyz[,3], 
                 INDEX = list(ix, iy), 
                 FUN   = sum)
  zlen <- tapply(input.xyz[,3], 
                 INDEX = list(ix, iy), 
                 FUN   = length)
  
  # create x and y values - select only values 
  x  <- xor[1] + as.integer(rownames(zsum))* dxo
  ii <- which(x >= xor[1] & x<= xor[2])
  
  y  <- yor[1] + as.integer(colnames(zsum))* dyo
  jj <- which(y >= yor[1] & y<= yor[2])
  
  out <- list(x[ii], y[jj], zsum[ii,jj] / zlen[ii,jj])
  names(out) <- colnames(input.xyz)[1:3]
  return(out)
  }
}

# ==============================================================================
# ==============================================================================
# maps gridded values on a regular grid
# ==============================================================================
# ==============================================================================

interpolate_2D_2D <- function(input.x, input.y, input.2D, 
                              output.x=NULL, output.y=NULL){
  
  if (is.null(output.x)) 
    output.x <- sort(unique(input.x))
  if (is.null(output.y)) 
    output.y <- sort(unique(input.y))
  
 # output grid size
  xo  <- unique(output.x)
  xor <- range(xo)

  yo <- unique(output.y)
  yor <- range(yo)

  xi  <- unique(input.x)
  xir <- range(xi)
  
  yi <- unique(input.y)
  yir <- range(yi)
  
  if (diff(range(diff(xi))) != 0 | diff(range(diff(yi))) != 0)
    stop("cannot interpolate - grid sizes are not constant")
  
  # input grid size
  dxi <- min(diff(sort(unique(input.x))))
  dyi <- min(diff(sort(unique(input.y))))
  
  dxi <- min(diff(sort(unique(input.x))))
  dyi <- min(diff(sort(unique(input.y))))
  
  # map output to input grid cells
  ix <- pmin(length(input.x), as.integer(1+(output.x-xir[1])/dxi))
  iy <- pmin(length(input.y), as.integer(1+(output.y-yir[1])/dyi))

  in2D <- cbind(input.2D[,1], input.2D, input.2D[,ncol(input.2D)])
  in2D <- rbind(in2D[1,],in2D,     in2D    [nrow(in2D),])
  
  IG   <- as.matrix(expand.grid(ix, iy))
  IGx1 <- t(t(IG) + c(1,0))
  OX   <- rep(output.x, times=length(output.y))
  zx   <- in2D[IG] + (in2D[IGx1]-in2D[IG])*(OX-input.x[IG[,1]])/dxi  
  zx   <- matrix(nrow=length(output.x), ncol=length(output.y), data=zx)
#  ZX<<- zx
  
  IG   <- as.matrix(expand.grid(iy, ix))[, c(2,1)]
  IGy1 <- t(t(IG) + c(0,1))
  OY   <- rep(output.y, times=length(output.x))
  zy   <- in2D[IG] + (in2D[IGy1]-in2D[IG])*(OY-input.y[IG[,2]])/dyi  
  zy   <- matrix(nrow=length(output.x), ncol=length(output.y), data=zy, byrow=TRUE)
  zz   <- 0.5*(zx+zy)
#  ZY<<- zy
  
  out <- list(x=output.x, y=output.y, z=(zx+zy)/2)
  out
}


# ==============================================================================

interpolate_xt <-  function(input.xtv, # position (x), time (t), value
                            output.x, output.t){
  
  if (ncol(input.xtv) != 3) 
    stop ("'input.xtv' should have 3 columns: position (x), time (t), value")
 
   ############## TO DO ############### 
 }
